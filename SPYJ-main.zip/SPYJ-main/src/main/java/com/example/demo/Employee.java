package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;
    private String name;
    private String Last_Name;
    private String email;
    private String working_days;
    private String emp_leave;
    private String mobile_number;
    private String report_head;
    private String remark;
    private byte[] photo;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWorking_days() {
		return working_days;
	}
	public void setWorking_days(String working_days) {
		this.working_days = working_days;
	}
	public String getEmp_leave() {
		return emp_leave;
	}
	public void setEmp_leave(String emp_leave) {
		this.emp_leave = emp_leave;
	}
	public String getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}
	
	
	
	public String getReport_head() {
		return report_head;
	}
	public void setReport_head(String report_head) {
		this.report_head = report_head;
	}
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	
	public Employee(long id, String name, String last_Name, String email, String working_days, String emp_leave,
			String mobile_number, String report_head, String remark, byte[] photo) {
		super();
		this.id = id;
		this.name = name;
		Last_Name = last_Name;
		this.email = email;
		this.working_days = working_days;
		this.emp_leave = emp_leave;
		this.mobile_number = mobile_number;
		this.report_head = report_head;
		this.remark = remark;
		this.photo = photo;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}	
    
    
}